"""
LLM 驱动的记忆抽取服务

用 LLM 替代正则匹配，从对话中智能抽取需要长期记忆的信息，
并自动存储到对应的记忆层（KV 变量 / 语义片段）。
"""
import logging
import json
import re
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)

from app.services.llm_backend_service import llm_chat
from app.services.memory_variable_service import set_memory_variable
from app.services.memory_fragment_service import create_fragment

# ============================================================
# 抽取 Prompt
# ============================================================

EXTRACTION_SYSTEM_PROMPT = """你是一个记忆抽取引擎。你的任务是从对话中识别需要长期记忆的信息。

请从对话中抽取以下类型的信息：
1. **variables**: 用户的基本信息、偏好设置等 KV 型数据（如姓名、角色、项目名、技术栈偏好等）
2. **facts**: 重要的事实性信息（如"用户在做一个叫源启的项目"）
3. **preferences**: 用户的偏好和习惯（如"用户喜欢用 React"、"偏好简洁的代码风格"）
4. **plans**: 用户的计划和目标（如"下周要完成原型设计"）

规则：
- 只抽取有**长期价值**的信息，忽略临时性内容（如"今天天气不错"、"帮我写个函数"）
- 如果对话中没有值得记忆的信息，返回空对象
- 每个字段要简洁、准确
- 必须返回合法的 JSON，不要包含其他文字

返回格式：
```json
{
  "variables": [
    {"key": "user_name", "value": "鑫海"},
    {"key": "user_role", "value": "产品经理"}
  ],
  "facts": [
    "用户正在开发一个叫源启·智能体工厂的项目",
    "用户负责 Agent 记忆系统的架构设计"
  ],
  "preferences": [
    "用户偏好使用 Python 和 FastAPI"
  ],
  "plans": [
    "下周完成原型设计"
  ]
}
```"""


def _build_extraction_messages(conversation: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    构建抽取请求的 messages 列表。

    Args:
        conversation: 对话历史 [{"role": "user/assistant", "content": "..."}]

    Returns:
        用于 LLM 抽取的 messages
    """
    # 拼接对话文本
    dialogue_parts = []
    for msg in conversation:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        if role == "user":
            dialogue_parts.append(f"用户: {content}")
        elif role == "assistant":
            dialogue_parts.append(f"助手: {content}")

    dialogue_text = "\n".join(dialogue_parts)

    return [
        {"role": "system", "content": EXTRACTION_SYSTEM_PROMPT},
        {
            "role": "user",
            "content": f"请从以下对话中抽取需要长期记忆的信息：\n\n{dialogue_text}",
        },
    ]


def _parse_llm_response(response_text: str) -> Dict[str, Any]:
    """
    解析 LLM 返回的 JSON 抽取结果。

    支持处理 markdown 代码块包裹的 JSON。

    Args:
        response_text: LLM 返回的文本

    Returns:
        解析后的字典，解析失败返回空字典
    """
    if not response_text:
        return {}

    text = response_text.strip()

    # 尝试提取 markdown 代码块中的 JSON
    code_block_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if code_block_match:
        text = code_block_match.group(1).strip()

    # 尝试直接提取 JSON 对象
    json_match = re.search(r"\{.*\}", text, re.DOTALL)
    if json_match:
        text = json_match.group(0)

    try:
        # 清理控制字符
        text = ''.join(c if c.isprintable() or c in '\n\r\t' else ' ' for c in text)
        result = json.loads(text, strict=False)
        if isinstance(result, dict):
            return result
    except (json.JSONDecodeError, ValueError):
        logger.warning(f"LLM 抽取结果解析失败: {response_text[:200]}")

    return {}


def llm_extract_memories(
    user_id: int,
    conversation: List[Dict[str, str]],
    auto_store: bool = True,
) -> Dict[str, Any]:
    """
    用 LLM 从对话中智能抽取记忆。

    Args:
        user_id: 用户 ID
        conversation: 对话历史 [{"role": "user/assistant", "content": "..."}]
        auto_store: 是否自动存储抽取结果（默认 True）

    Returns:
        抽取结果字典：
        {
            "success": True,
            "variables": [{"key": ..., "value": ...}],
            "facts": [...],
            "preferences": [...],
            "plans": [...],
            "stored_count": N
        }
    """
    try:
        if not conversation:
            return {"success": True, "variables": [], "facts": [], "preferences": [], "plans": [], "stored_count": 0}

        # 1. 构建抽取请求
        messages = _build_extraction_messages(conversation)

        # 2. 调用 LLM
        llm_result = llm_chat(user_id=user_id, messages=messages, temperature=0.1)

        if not llm_result.get("success"):
            logger.warning(f"LLM 抽取调用失败: {llm_result.get('error', 'unknown')}")
            return {
                "success": False,
                "error": llm_result.get("error", "LLM call failed"),
                "variables": [],
                "facts": [],
                "preferences": [],
                "plans": [],
                "stored_count": 0,
            }

        response_text = llm_result.get("content", "")

        # 3. 解析结果
        extracted = _parse_llm_response(response_text)

        variables = extracted.get("variables", [])
        facts = extracted.get("facts", [])
        preferences = extracted.get("preferences", [])
        plans = extracted.get("plans", [])

        stored_count = 0

        # 4. 自动存储
        if auto_store:
            # 4a. 存储 KV 变量
            for var in variables:
                key = var.get("key", "").strip()
                value = var.get("value", "").strip()
                if key and value:
                    ok = set_memory_variable(
                        user_id=user_id, key=key, value=value
                    )
                    if ok:
                        stored_count += 1

            # 4b. 存储事实片段
            for fact in facts:
                if fact and str(fact).strip():
                    result = create_fragment(
                        user_id=user_id,
                        fragment_type="info",
                        content=str(fact).strip(),
                        importance_score=0.6,
                    )
                    if result.get("success"):
                        stored_count += 1

            # 4c. 存储偏好片段
            for pref in preferences:
                if pref and str(pref).strip():
                    result = create_fragment(
                        user_id=user_id,
                        fragment_type="preference",
                        content=str(pref).strip(),
                        importance_score=0.5,
                    )
                    if result.get("success"):
                        stored_count += 1

            # 4d. 存储计划片段
            for plan in plans:
                if plan and str(plan).strip():
                    result = create_fragment(
                        user_id=user_id,
                        fragment_type="plan",
                        content=str(plan).strip(),
                        importance_score=0.5,
                    )
                    if result.get("success"):
                        stored_count += 1

        logger.info(
            f"LLM 抽取完成: {len(variables)} 变量, {len(facts)} 事实, "
            f"{len(preferences)} 偏好, {len(plans)} 计划, 存储 {stored_count} 条"
        )

        return {
            "success": True,
            "variables": variables,
            "facts": facts,
            "preferences": preferences,
            "plans": plans,
            "stored_count": stored_count,
        }

    except Exception as e:
        logger.error(f"LLM 记忆抽取失败: {e}")
        return {
            "success": False,
            "error": str(e),
            "variables": [],
            "facts": [],
            "preferences": [],
            "plans": [],
            "stored_count": 0,
        }
