"""
Agent 循环编排服务

实现记忆感知的 Agent 对话循环：
  用户输入 → 记忆召回 → 注入上下文 → LLM 推理（含 Tool Calling）→ 记忆抽取 → 响应
"""
import logging
import json
from typing import Optional, Dict, Any, List

logger = logging.getLogger(__name__)

from app.services.agent_memory_sdk import AgentMemoryClient
from app.services.llm_backend_service import llm_chat
from app.services.llm_extraction_service import llm_extract_memories

# ============================================================
# Tool Schema 定义（OpenAI Function Calling 格式）
# ============================================================

MEMORY_TOOLS: List[Dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "memory_recall",
            "description": "召回与查询相关的历史记忆信息，返回格式化的记忆上下文",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "要回忆/搜索的内容描述",
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "返回记忆条数，默认 5",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "memory_remember",
            "description": "记住一条新的信息，供未来对话使用",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {
                        "type": "string",
                        "description": "记忆的名称/键",
                    },
                    "value": {
                        "type": "string",
                        "description": "记忆的内容/值",
                    },
                },
                "required": ["key", "value"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "memory_forget",
            "description": "删除一条已存储的记忆变量",
            "parameters": {
                "type": "object",
                "properties": {
                    "key": {
                        "type": "string",
                        "description": "要删除的记忆名称/键",
                    },
                },
                "required": ["key"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "memory_search",
            "description": "语义搜索记忆片段，返回匹配的记忆列表",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "搜索查询",
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "返回条数，默认 5",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "memory_get_context",
            "description": "获取当前用户的完整记忆上下文",
            "parameters": {
                "type": "object",
                "properties": {},
            },
        },
    },
]


# ============================================================
# Tool Handler
# ============================================================

def _handle_tool_call(sdk: AgentMemoryClient, tool_name: str, arguments: Dict[str, Any]) -> str:
    """
    执行单个工具调用，返回结果字符串。

    Args:
        sdk: AgentMemoryClient 实例
        tool_name: 工具名称
        arguments: 工具参数

    Returns:
        工具执行结果（JSON 字符串）
    """
    try:
        if tool_name == "memory_recall":
            result = sdk.recall(
                query=arguments.get("query", ""),
                top_k=arguments.get("top_k", 5),
            )
            return json.dumps({"success": True, "context": result}, ensure_ascii=False)

        elif tool_name == "memory_remember":
            ok = sdk.remember(
                key=arguments.get("key", ""),
                value=arguments.get("value", ""),
            )
            return json.dumps({"success": ok, "key": arguments.get("key", "")}, ensure_ascii=False)

        elif tool_name == "memory_forget":
            ok = sdk.forget(key=arguments.get("key", ""))
            return json.dumps({"success": ok, "key": arguments.get("key", "")}, ensure_ascii=False)

        elif tool_name == "memory_search":
            results = sdk.search(
                query=arguments.get("query", ""),
                top_k=arguments.get("top_k", 5),
            )
            return json.dumps({"success": True, "memories": results, "count": len(results)}, ensure_ascii=False)

        elif tool_name == "memory_get_context":
            ctx = sdk.get_context()
            return json.dumps({"success": True, "context": ctx}, ensure_ascii=False)

        else:
            return json.dumps({"success": False, "error": f"未知工具: {tool_name}"}, ensure_ascii=False)

    except Exception as e:
        logger.error(f"工具执行失败 [{tool_name}]: {e}")
        return json.dumps({"success": False, "error": str(e)}, ensure_ascii=False)


# ============================================================
# Agent Loop 核心编排
# ============================================================

DEFAULT_SYSTEM_PROMPT = """你是一个拥有长期记忆能力的智能助手。

你可以通过工具调用来管理记忆：
- memory_recall: 回忆与某个话题相关的历史记忆
- memory_remember: 记住一条新信息
- memory_forget: 删除一条记忆
- memory_search: 语义搜索记忆片段
- memory_get_context: 获取完整的记忆上下文

请充分利用记忆工具来提供个性化的回答。如果用户提到了之前聊过的内容，请使用 memory_recall 工具回忆相关信息。
"""


def memory_aware_chat(
    user_id: int,
    user_message: str,
    system_prompt: Optional[str] = None,
    session_id: Optional[str] = None,
    max_tool_rounds: int = 5,
) -> Dict[str, Any]:
    """
    记忆感知的 Agent 对话循环。

    流程：
    1. 自动召回相关记忆 → 注入 system prompt
    2. 调用 LLM（带 tool 定义）
    3. 如果 LLM 返回 tool_calls → 执行工具 → 结果追加到 messages → 回到步骤 2
    4. 如果 LLM 返回文本 → 从对话中抽取新记忆 → 返回响应

    Args:
        user_id: 用户 ID
        user_message: 用户消息
        system_prompt: 自定义 system prompt（可选）
        session_id: 会话 ID（可选）
        max_tool_rounds: 最大工具调用轮数（防止无限循环）

    Returns:
        对话结果：
        {
            "success": True,
            "response": "助手回复文本",
            "tool_calls": [...],
            "memories_extracted": N,
            "memory_context_used": True/False
        }
    """
    sdk = AgentMemoryClient(user_id)
    all_tool_calls: List[Dict[str, Any]] = []
    memory_context_used = False

    # ----------------------------------------------------------
    # 步骤 1：自动召回相关记忆，注入 system prompt
    # ----------------------------------------------------------
    base_prompt = system_prompt or DEFAULT_SYSTEM_PROMPT

    # 获取 KV 记忆变量上下文
    kv_context = sdk.get_context(session_id)

    # 语义召回相关记忆
    recalled_context = sdk.recall(user_message, top_k=5)

    # 合并上下文
    full_context_parts = []
    if kv_context:
        full_context_parts.append(kv_context)
    if recalled_context:
        full_context_parts.append(recalled_context)
    full_context = "\n\n".join(full_context_parts)

    if full_context:
        memory_context_used = True
        augmented_prompt = (
            f"{base_prompt}\n\n"
            f"---\n"
            f"以下是与该用户相关的历史记忆，请在回答时参考：\n\n"
            f"{full_context}\n"
            f"---"
        )
    else:
        augmented_prompt = base_prompt

    # ----------------------------------------------------------
    # 构建初始 messages
    # ----------------------------------------------------------
    messages: List[Dict[str, str]] = [
        {"role": "system", "content": augmented_prompt},
        {"role": "user", "content": user_message},
    ]

    # ----------------------------------------------------------
    # 步骤 2-3：LLM 推理 + Tool Calling 循环
    # ----------------------------------------------------------
    final_response = ""

    for round_idx in range(max_tool_rounds + 1):
        # 调用 LLM
        llm_result = llm_chat(
            user_id=user_id,
            messages=messages,
            tools=MEMORY_TOOLS,
        )

        if not llm_result.get("success"):
            logger.error(f"LLM 调用失败: {llm_result.get('error')}")
            final_response = f"抱歉，AI 服务暂时不可用：{llm_result.get('error', '未知错误')}"
            break

        # 检查是否有 tool_calls
        tool_calls = llm_result.get("tool_calls")

        if not tool_calls:
            # 没有 tool_calls → LLM 返回了最终文本
            final_response = llm_result.get("content", "")
            break

        # 有 tool_calls → 执行工具
        # 先将 assistant 的 tool_calls 消息追加
        assistant_msg = {
            "role": "assistant",
            "content": llm_result.get("content", "") or "",
            "tool_calls": tool_calls,
        }
        messages.append(assistant_msg)

        for tc in tool_calls:
            func_name = tc.get("function", {}).get("name", "")
            func_args_str = tc.get("function", {}).get("arguments", "{}")
            tool_call_id = tc.get("id", "")

            try:
                func_args = json.loads(func_args_str) if isinstance(func_args_str, str) else func_args_str
            except json.JSONDecodeError:
                func_args = {}

            # 执行工具
            tool_result = _handle_tool_call(sdk, func_name, func_args)

            all_tool_calls.append({
                "tool": func_name,
                "arguments": func_args,
                "result": tool_result,
            })

            # 将工具结果追加到 messages
            messages.append({
                "role": "tool",
                "tool_call_id": tool_call_id,
                "content": tool_result,
            })

    else:
        # 超过最大轮数
        if not final_response:
            final_response = llm_result.get("content", "抱歉，工具调用轮数已达上限。")

    # ----------------------------------------------------------
    # 步骤 4：从对话中抽取新记忆（异步/后台）
    # ----------------------------------------------------------
    memories_extracted = 0
    try:
        conversation_for_extraction = [
            {"role": "user", "content": user_message},
            {"role": "assistant", "content": final_response},
        ]
        extract_result = llm_extract_memories(
            user_id=user_id,
            conversation=conversation_for_extraction,
            auto_store=True,
        )
        memories_extracted = extract_result.get("stored_count", 0)
    except Exception as e:
        logger.warning(f"对话后记忆抽取失败（不影响响应）: {e}")

    return {
        "success": True,
        "response": final_response,
        "tool_calls": all_tool_calls,
        "memories_extracted": memories_extracted,
        "memory_context_used": memory_context_used,
    }
