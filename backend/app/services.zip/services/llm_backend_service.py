"""
LLM 后端集成服务

支持多种 LLM 后端（OpenAI、Claude、本地模型），提供统一接口和动态切换
"""
import logging
import json
import os
import hashlib
import time
from typing import Optional, Dict, Any, List
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)

from app.core.db_client import get_db_client


# ============================================================
# 抽象 LLM 后端接口
# ============================================================

class LLMBackend(ABC):
    """LLM 后端抽象基类"""

    @abstractmethod
    def chat(self, messages: List[Dict[str, str]], **kwargs) -> Dict[str, Any]:
        """发送聊天请求"""
        pass

    @abstractmethod
    def embed(self, text: str) -> List[float]:
        """生成文本嵌入向量"""
        pass

    @abstractmethod
    def get_info(self) -> Dict[str, Any]:
        """获取后端信息"""
        pass


# ============================================================
# OpenAI 后端
# ============================================================

class OpenAIBackend(LLMBackend):
    """OpenAI GPT 后端"""

    def __init__(self, config: Dict[str, Any]):
        self.api_key = config.get("api_key", "")
        self.model = config.get("model", "gpt-4")
        self.embedding_model = config.get("embedding_model", "text-embedding-ada-002")
        self.temperature = config.get("temperature", 0.7)
        self.max_tokens = config.get("max_tokens", 2000)
        self.base_url = config.get("base_url", "https://api.openai.com/v1")

    def chat(self, messages: List[Dict[str, str]], **kwargs) -> Dict[str, Any]:
        try:
            # 尝试使用 openai 库
            try:
                import openai
                client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)
                
                # 解析 tools 参数
                tools = kwargs.get("tools")
                api_kwargs = {
                    "model": kwargs.get("model", self.model),
                    "messages": messages,
                    "temperature": kwargs.get("temperature", self.temperature),
                    "max_tokens": kwargs.get("max_tokens", self.max_tokens),
                }
                if tools:
                    api_kwargs["tools"] = tools
                
                response = client.chat.completions.create(**api_kwargs)
                
                result = {
                    "success": True,
                    "content": response.choices[0].message.content,
                    "model": response.model,
                    "usage": {
                        "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                        "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                        "total_tokens": response.usage.total_tokens if response.usage else 0
                    }
                }
                
                # 处理 tool_calls
                if response.choices[0].message.tool_calls:
                    tool_calls = []
                    for tc in response.choices[0].message.tool_calls:
                        tool_calls.append({
                            "id": tc.id,
                            "type": tc.type,
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            }
                        })
                    result["tool_calls"] = tool_calls
                
                return result
            except ImportError:
                # openai 库未安装，返回模拟响应
                logger.warning("openai 库未安装，返回模拟响应")
                return self._mock_response(messages, "openai")
        except Exception as e:
            logger.error(f"✗ OpenAI 请求失败: {e}")
            return {"success": False, "error": str(e)}

    def embed(self, text: str) -> List[float]:
        try:
            try:
                import openai
                client = openai.OpenAI(api_key=self.api_key)
                response = client.embeddings.create(
                    model=self.embedding_model,
                    input=text
                )
                return response.data[0].embedding
            except ImportError:
                # 返回简单哈希向量作为模拟
                return self._mock_embedding(text)
        except Exception as e:
            logger.error(f"✗ OpenAI 嵌入失败: {e}")
            return []

    def get_info(self) -> Dict[str, Any]:
        return {
            "backend": "openai",
            "model": self.model,
            "embedding_model": self.embedding_model,
            "base_url": self.base_url,
            "configured": bool(self.api_key)
        }

    def _mock_response(self, messages: List[Dict[str, str]], backend: str) -> Dict[str, Any]:
        last_msg = messages[-1]["content"] if messages else ""
        return {
            "success": True,
            "content": f"[{backend} mock] I received: {last_msg[:100]}...",
            "model": self.model,
            "usage": {"prompt_tokens": len(last_msg) // 4, "completion_tokens": 20, "total_tokens": len(last_msg) // 4 + 20},
            "mock": True
        }

    def _mock_embedding(self, text: str) -> List[float]:
        hash_val = hashlib.md5(text.encode()).hexdigest()
        return [int(hash_val[i:i2], 16) / 0xFFFFFFFF for i, i2 in zip(range(0, 64, 8), range(8, 72, 8))]


# ============================================================
# Claude 后端
# ============================================================

class ClaudeBackend(LLMBackend):
    """Anthropic Claude 后端"""

    def __init__(self, config: Dict[str, Any]):
        self.api_key = config.get("api_key", "")
        self.model = config.get("model", "claude-3-sonnet-20240229")
        self.max_tokens = config.get("max_tokens", 2000)
        self.temperature = config.get("temperature", 0.7)

    def chat(self, messages: List[Dict[str, str]], **kwargs) -> Dict[str, Any]:
        try:
            try:
                import anthropic
                client = anthropic.Anthropic(api_key=self.api_key)
                # Claude 格式转换
                system_msg = ""
                claude_messages = []
                for msg in messages:
                    if msg["role"] == "system":
                        system_msg = msg["content"]
                    else:
                        claude_messages.append(msg)

                response = client.messages.create(
                    model=kwargs.get("model", self.model),
                    max_tokens=kwargs.get("max_tokens", self.max_tokens),
                    temperature=kwargs.get("temperature", self.temperature),
                    system=system_msg,
                    messages=claude_messages
                )
                return {
                    "success": True,
                    "content": response.content[0].text,
                    "model": response.model,
                    "usage": {
                        "prompt_tokens": response.usage.input_tokens,
                        "completion_tokens": response.usage.output_tokens,
                        "total_tokens": response.usage.input_tokens + response.usage.output_tokens
                    }
                }
            except ImportError:
                logger.warning("anthropic 库未安装，返回模拟响应")
                last_msg = messages[-1]["content"] if messages else ""
                return {
                    "success": True,
                    "content": f"[claude mock] I received: {last_msg[:100]}...",
                    "model": self.model,
                    "usage": {"prompt_tokens": len(last_msg) // 4, "completion_tokens": 20, "total_tokens": len(last_msg) // 4 + 20},
                    "mock": True
                }
        except Exception as e:
            logger.error(f"✗ Claude 请求失败: {e}")
            return {"success": False, "error": str(e)}

    def embed(self, text: str) -> List[float]:
        # Claude 不提供嵌入 API，使用模拟（基于 MD5 hash 生成 8 维向量）
        hash_val = hashlib.md5(text.encode()).hexdigest()
        return [int(hash_val[i:i+4], 16) / 0xFFFF for i in range(0, 32, 4)]

    def get_info(self) -> Dict[str, Any]:
        return {
            "backend": "claude",
            "model": self.model,
            "configured": bool(self.api_key)
        }


# ============================================================
# 本地模型后端
# ============================================================

class LocalModelBackend(LLMBackend):
    """本地模型后端（如 Llama、ChatGLM）"""

    def __init__(self, config: Dict[str, Any]):
        self.model_path = config.get("model_path", "")
        self.model_type = config.get("model_type", "llama")
        self.api_url = config.get("api_url", "http://localhost:8080")
        self.max_tokens = config.get("max_tokens", 2000)
        self.temperature = config.get("temperature", 0.7)

    def chat(self, messages: List[Dict[str, str]], **kwargs) -> Dict[str, Any]:
        try:
            import urllib.request
            import urllib.error

            payload = json.dumps({
                "model": self.model_type,
                "messages": messages,
                "temperature": kwargs.get("temperature", self.temperature),
                "max_tokens": kwargs.get("max_tokens", self.max_tokens)
            }).encode("utf-8")

            req = urllib.request.Request(
                f"{self.api_url}/v1/chat/completions",
                data=payload,
                headers={"Content-Type": "application/json"}
            )

            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
                    return {
                        "success": True,
                        "content": result["choices"][0]["message"]["content"],
                        "model": result.get("model", self.model_type),
                        "usage": result.get("usage", {})
                    }
            except (urllib.error.URLError, ConnectionError):
                logger.warning(f"本地模型服务不可达 ({self.api_url})，返回模拟响应")
                last_msg = messages[-1]["content"] if messages else ""
                return {
                    "success": True,
                    "content": f"[local mock] I received: {last_msg[:100]}...",
                    "model": self.model_type,
                    "usage": {"prompt_tokens": len(last_msg) // 4, "completion_tokens": 20, "total_tokens": len(last_msg) // 4 + 20},
                    "mock": True
                }
        except Exception as e:
            logger.error(f"✗ 本地模型请求失败: {e}")
            return {"success": False, "error": str(e)}

    def embed(self, text: str) -> List[float]:
        try:
            import urllib.request
            payload = json.dumps({"input": text}).encode("utf-8")
            req = urllib.request.Request(
                f"{self.api_url}/v1/embeddings",
                data=payload,
                headers={"Content-Type": "application/json"}
            )
            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
                    return result["data"][0]["embedding"]
            except (urllib.error.URLError, ConnectionError):
                hash_val = hashlib.md5(text.encode()).hexdigest()
                return [int(hash_val[i:i2], 16) / 0xFFFFFFFF for i, i2 in zip(range(0, 64, 8), range(8, 72, 8))]
        except Exception:
            return []

    def get_info(self) -> Dict[str, Any]:
        return {
            "backend": "local",
            "model_type": self.model_type,
            "model_path": self.model_path,
            "api_url": self.api_url,
            "configured": bool(self.api_url)
        }


# ============================================================
# 后端工厂和管理器
# ============================================================

BACKEND_REGISTRY = {
    "openai": OpenAIBackend,
    "claude": ClaudeBackend,
    "local": LocalModelBackend,
}


def _ensure_llm_config_table():
    """确保 LLM 配置表存在"""
    db = get_db_client()
    db.execute('''
        CREATE TABLE IF NOT EXISTS llm_configs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            backend_name TEXT NOT NULL,
            backend_type TEXT NOT NULL,
            config TEXT NOT NULL,
            is_active INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, backend_name),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    db.execute('CREATE INDEX IF NOT EXISTS idx_llm_config_user ON llm_configs(user_id)')


def get_llm_backend(user_id: int, backend_name: Optional[str] = None) -> Dict[str, Any]:
    """
    获取 LLM 后端实例

    Args:
        user_id: 用户 ID
        backend_name: 指定后端名称，None 则使用当前激活的后端

    Returns:
        后端实例和信息
    """
    try:
        _ensure_llm_config_table()
        db = get_db_client()

        if backend_name:
            rows = db.execute(
                'SELECT * FROM llm_configs WHERE user_id = ? AND backend_name = ?',
                (user_id, backend_name)
            )
        else:
            rows = db.execute(
                'SELECT * FROM llm_configs WHERE user_id = ? AND is_active = 1 ORDER BY updated_at DESC LIMIT 1',
                (user_id,)
            )

        if not rows:
            # 返回默认 DeepSeek 后端（OpenAI 兼容接口）
            default_config = {
                "api_key": os.environ.get("LLM_API_KEY", "sk-3cb5299e0bbc4456a05da93d1eff617f"),
                "model": os.environ.get("LLM_MODEL", "deepseek-chat"),
                "base_url": os.environ.get("LLM_BASE_URL", "https://api.deepseek.com/v1"),
                "temperature": 0.7,
            }
            backend = OpenAIBackend(default_config)
            return {
                "success": True,
                "backend": backend,
                "info": backend.get_info(),
                "is_default": True
            }

        row = dict(rows[0])
        config = json.loads(row["config"])
        backend_type = row["backend_type"]

        if backend_type not in BACKEND_REGISTRY:
            return {"success": False, "error": f"Unknown backend type: {backend_type}"}

        backend = BACKEND_REGISTRY[backend_type](config)

        return {
            "success": True,
            "backend": backend,
            "info": backend.get_info(),
            "is_default": False,
            "backend_name": row["backend_name"]
        }

    except Exception as e:
        logger.error(f"✗ 获取 LLM 后端失败: {e}")
        return {"success": False, "error": str(e)}


def register_llm_backend(user_id: int,
                         backend_name: str,
                         backend_type: str,
                         config: Dict[str, Any],
                         set_active: bool = True) -> Dict[str, Any]:
    """
    注册/更新 LLM 后端配置

    Args:
        user_id: 用户 ID
        backend_name: 后端名称（如 "my-openai", "local-llama"）
        backend_type: 后端类型（openai, claude, local）
        config: 后端配置
        set_active: 是否设为当前激活后端

    Returns:
        注册结果
    """
    try:
        _ensure_llm_config_table()
        db = get_db_client()

        if backend_type not in BACKEND_REGISTRY:
            return {"success": False, "error": f"Unsupported backend type: {backend_type}. Supported: {list(BACKEND_REGISTRY.keys())}"}

        config_str = json.dumps(config, ensure_ascii=False)

        # 如果设为激活，先取消其他激活
        if set_active:
            db.execute(
                'UPDATE llm_configs SET is_active = 0 WHERE user_id = ?',
                (user_id,)
            )

        # 插入或更新
        existing = db.execute(
            'SELECT id FROM llm_configs WHERE user_id = ? AND backend_name = ?',
            (user_id, backend_name)
        )

        if existing:
            db.execute(
                'UPDATE llm_configs SET backend_type = ?, config = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND backend_name = ?',
                (backend_type, config_str, 1 if set_active else 0, user_id, backend_name)
            )
        else:
            db.execute(
                'INSERT INTO llm_configs (user_id, backend_name, backend_type, config, is_active) VALUES (?, ?, ?, ?, ?)',
                (user_id, backend_name, backend_type, config_str, 1 if set_active else 0)
            )

        logger.info(f"✓ 注册 LLM 后端: {backend_name} ({backend_type})")

        return {
            "success": True,
            "backend_name": backend_name,
            "backend_type": backend_type,
            "is_active": set_active,
            "message": f"Backend '{backend_name}' registered successfully"
        }

    except Exception as e:
        logger.error(f"✗ 注册 LLM 后端失败: {e}")
        return {"success": False, "error": str(e)}


def switch_backend(user_id: int, backend_name: str) -> Dict[str, Any]:
    """
    切换当前激活的 LLM 后端

    Args:
        user_id: 用户 ID
        backend_name: 要切换到的后端名称

    Returns:
        切换结果
    """
    try:
        _ensure_llm_config_table()
        db = get_db_client()

        # 检查后端是否存在
        rows = db.execute(
            'SELECT * FROM llm_configs WHERE user_id = ? AND backend_name = ?',
            (user_id, backend_name)
        )

        if not rows:
            return {"success": False, "error": f"Backend '{backend_name}' not found"}

        # 取消其他激活
        db.execute(
            'UPDATE llm_configs SET is_active = 0 WHERE user_id = ?',
            (user_id,)
        )

        # 激活指定后端
        db.execute(
            'UPDATE llm_configs SET is_active = 1, updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND backend_name = ?',
            (user_id, backend_name)
        )

        row = dict(rows[0])
        config = json.loads(row["config"])
        backend = BACKEND_REGISTRY[row["backend_type"]](config)

        logger.info(f"✓ 切换 LLM 后端: {backend_name}")

        return {
            "success": True,
            "backend_name": backend_name,
            "backend_type": row["backend_type"],
            "info": backend.get_info(),
            "message": f"Switched to backend '{backend_name}'"
        }

    except Exception as e:
        logger.error(f"✗ 切换后端失败: {e}")
        return {"success": False, "error": str(e)}


def list_backends(user_id: int) -> Dict[str, Any]:
    """列出用户的所有 LLM 后端配置"""
    try:
        _ensure_llm_config_table()
        db = get_db_client()

        rows = db.execute(
            'SELECT backend_name, backend_type, is_active, created_at, updated_at FROM llm_configs WHERE user_id = ? ORDER BY is_active DESC, updated_at DESC',
            (user_id,)
        )

        backends = []
        if rows:
            for row in rows:
                r = dict(row)
                backends.append({
                    "name": r["backend_name"],
                    "type": r["backend_type"],
                    "is_active": bool(r["is_active"]),
                    "created_at": r["created_at"],
                    "updated_at": r["updated_at"]
                })

        return {
            "success": True,
            "backends": backends,
            "count": len(backends),
            "available_types": list(BACKEND_REGISTRY.keys())
        }

    except Exception as e:
        logger.error(f"✗ 列出后端失败: {e}")
        return {"success": False, "error": str(e)}


def delete_backend(user_id: int, backend_name: str) -> Dict[str, Any]:
    """删除 LLM 后端配置"""
    try:
        _ensure_llm_config_table()
        db = get_db_client()

        db.execute(
            'DELETE FROM llm_configs WHERE user_id = ? AND backend_name = ?',
            (user_id, backend_name)
        )

        return {
            "success": True,
            "message": f"Backend '{backend_name}' deleted"
        }

    except Exception as e:
        logger.error(f"✗ 删除后端失败: {e}")
        return {"success": False, "error": str(e)}


def llm_chat(user_id: int, messages: List[Dict[str, str]], backend_name: Optional[str] = None, **kwargs) -> Dict[str, Any]:
    """
    使用配置的 LLM 后端发送聊天请求

    Args:
        user_id: 用户 ID
        messages: 消息列表
        backend_name: 指定后端（None 使用激活的后端）
        **kwargs: 额外参数（temperature, max_tokens 等）

    Returns:
        聊天响应
    """
    result = get_llm_backend(user_id, backend_name)
    if not result["success"]:
        return result

    backend = result["backend"]
    return backend.chat(messages, **kwargs)


def llm_embed(user_id: int, text: str, backend_name: Optional[str] = None) -> Dict[str, Any]:
    """
    使用配置的 LLM 后端生成嵌入向量

    Args:
        user_id: 用户 ID
        text: 要嵌入的文本
        backend_name: 指定后端

    Returns:
        嵌入向量
    """
    result = get_llm_backend(user_id, backend_name)
    if not result["success"]:
        return result

    backend = result["backend"]
    embedding = backend.embed(text)

    return {
        "success": True,
        "embedding": embedding,
        "dimensions": len(embedding)
    }


# ============================================================
# 测试
# ============================================================

def test_llm_backend():
    """测试 LLM 后端集成"""
    print("\n" + "="*60)
    print("测试 LLM 后端集成服务")
    print("="*60 + "\n")

    user_id = 999

    # 清理
    db = get_db_client()
    _ensure_llm_config_table()
    db.execute('DELETE FROM llm_configs WHERE user_id = ?', (user_id,))

    print("1. 测试注册 OpenAI 后端...")
    result = register_llm_backend(user_id, "my-openai", "openai", {
        "api_key": "test-key",
        "model": "gpt-4",
        "temperature": 0.5
    })
    print(f"   结果: {result.get('success')}")
    assert result["success"] == True
    print(f"   ✓ OpenAI 后端注册成功\n")

    print("2. 测试注册 Claude 后端...")
    result = register_llm_backend(user_id, "my-claude", "claude", {
        "api_key": "test-key",
        "model": "claude-3-sonnet-20240229"
    }, set_active=False)
    print(f"   结果: {result.get('success')}")
    assert result["success"] == True
    print(f"   ✓ Claude 后端注册成功\n")

    print("3. 测试注册本地模型后端...")
    result = register_llm_backend(user_id, "local-llama", "local", {
        "model_type": "llama",
        "api_url": "http://localhost:8080"
    }, set_active=False)
    print(f"   结果: {result.get('success')}")
    assert result["success"] == True
    print(f"   ✓ 本地模型后端注册成功\n")

    print("4. 测试列出所有后端...")
    result = list_backends(user_id)
    print(f"   后端数: {result.get('count', 0)}")
    for b in result.get("backends", []):
        active = "✓" if b["is_active"] else " "
        print(f"   [{active}] {b['name']} ({b['type']})")
    assert result["count"] == 3
    print(f"   ✓ 列出后端成功\n")

    print("5. 测试获取当前激活后端...")
    result = get_llm_backend(user_id)
    print(f"   后端信息: {result.get('info')}")
    assert result["success"] == True
    print(f"   ✓ 获取激活后端成功\n")

    print("6. 测试切换后端...")
    result = switch_backend(user_id, "my-claude")
    print(f"   切换结果: {result.get('success')}")
    print(f"   新后端: {result.get('backend_type')}")
    assert result["success"] == True
    print(f"   ✓ 后端切换成功\n")

    print("7. 测试聊天（mock 模式）...")
    result = llm_chat(user_id, [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello!"}
    ])
    print(f"   响应: {result.get('content', '')[:80]}...")
    print(f"   Mock: {result.get('mock', False)}")
    assert result["success"] == True
    print(f"   ✓ 聊天请求成功\n")

    print("8. 测试嵌入向量生成...")
    result = llm_embed(user_id, "test text for embedding")
    print(f"   向量维度: {result.get('dimensions', 0)}")
    assert result["success"] == True
    assert result["dimensions"] > 0
    print(f"   ✓ 嵌入向量生成成功\n")

    print("9. 测试指定后端聊天...")
    result = llm_chat(user_id, [{"role": "user", "content": "Hi"}], backend_name="local-llama")
    print(f"   响应: {result.get('content', '')[:80]}...")
    assert result["success"] == True
    print(f"   ✓ 指定后端聊天成功\n")

    print("10. 测试删除后端...")
    result = delete_backend(user_id, "local-llama")
    print(f"   结果: {result.get('success')}")
    assert result["success"] == True
    result = list_backends(user_id)
    assert result["count"] == 2
    print(f"   ✓ 删除后端成功\n")

    # 清理
    db.execute('DELETE FROM llm_configs WHERE user_id = ?', (user_id,))

    print("="*60)
    print("✅ LLM 后端集成服务测试完成！")
    print("="*60 + "\n")

    return True


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    test_llm_backend()
